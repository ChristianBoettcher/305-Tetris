package view;

import java.awt.EventQueue;
/**
 * this is the main class for the game Tetris.
 * @author Christian Boettcher
 * @version Dec. 11 2015
 */
public final class TetrisMain {
    
    /**
     * the constructor (which is not to be instantiated). 
     */
    private TetrisMain() {
        throw new IllegalStateException();
    }

    /**
     * the main method kicks of the program PowerPaint.
     * @param theArgs = arguments from the command line.
     */
    public static void main(final String[] theArgs) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                TetrisGUI.start();
            }
        });
    }
}

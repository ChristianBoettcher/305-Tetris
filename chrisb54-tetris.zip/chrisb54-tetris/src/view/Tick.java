package view;

import java.awt.event.ActionEvent;   
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.Timer;

import model.Board;

/**
 * a class responsible for making the game go.
 * @author Christian
 * @version Dec. 12 2015
 */
public class Tick {
    
    /** 
     * The default delay (in milliseconds) for the move timer. 
     */
    public static final int MOVE_DELAY = 1000;

    /** 
     * The initial delay (in milliseconds) for the move timer. 
     */
    public static final int INITIAL_DELAY = 0;
    /**
     * Roman numeral 100 (multiplied by the current level and subtracted from the 
     *  delay to speed up the game).
     */
    private static final int C = 100;
    
    /** 
     * The timer that controls the movement of the shape.
     */
    private static Timer myMoveTimer;
    /**
     * the boolean variable to stop the timer.
     */
    private static boolean myPause;
    /**
     * the Board object acted upon.
     */
    private final Board myBoard;
    /**
     * Constructor for Tick object instantiating a Timer and a Board.
     * @param theBoard = the Board object running on the back end and ran by the timer.  
     */
    public Tick(final Board theBoard) {
        myMoveTimer = new Timer(MOVE_DELAY, new StepListener());
        myMoveTimer.setInitialDelay(INITIAL_DELAY);
        
        myBoard = theBoard;
    }

    /** 
     * Starts the timer. 
     */
    public void start() {
        myPause = false;
        myMoveTimer.start();
    }
    /**
     * Stops the timer.
     */
    public void stop() {
        myPause = true;
        myMoveTimer.stop();
    }
    /**
     * toggles the timer.
     */
    public static void startStop() {
        if (myPause) {
            myMoveTimer.start();
            myPause = false;
        } else {
            myMoveTimer.stop();
            myPause = true;
        }
    }
    /**
     * this inner class is designed to handle the speed of each time a Tick object ticks.
     * @author Christian
     * @version Dec. 12 2015
     */
    private class StepListener implements ActionListener {
        
        @Override
        public void actionPerformed(final ActionEvent theEvent) {
            if (!myBoard.isGameOver()) {
                myBoard.step();
                myMoveTimer.setDelay(MOVE_DELAY - (C * (ScorePanel.getLevel() - 1)));
            } else {
                myMoveTimer.stop();
                desplayGameOver();              
            }
            
        }
        /**
         * this displays a JOptionPane to notify the player that the game is over.
         */
        private void desplayGameOver() {
            final JOptionPane gameOver = new JOptionPane("gameOver");
            JOptionPane.showMessageDialog(gameOver, "the Game is now over");
            gameOver.setVisible(true);
        }
    }
}

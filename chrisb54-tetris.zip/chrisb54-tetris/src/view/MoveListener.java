package view;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import model.Board;
/**
 * this creates a KeyListener which sets keys to movement on the Board object.
 * @author Christian
 * @version Dec. 11 2015
 */
public class MoveListener implements KeyListener {
    /**
     * the board object being acted upon.
     */
    private final Board myBoard;
    /**
     * whether or not to disable during pause.
     */
    private boolean myDisable;
    /**
     * the constructor setting up myBoard and setting myDisable to false.
     * @param theBoard =  the Board object that is acted upon. 
     */
    public MoveListener(final Board theBoard) {
        myBoard = theBoard;
        myDisable = false;
    }

 
  
    @Override
    public void keyPressed(final KeyEvent arg0) {
        // Auto-generated method stub 
    }              
                
  
    @Override
    public void keyReleased(final KeyEvent arg0) {
        // Auto-generated method stub
        
    }
   
    @Override
    public void keyTyped(final KeyEvent arg0) {
        final char key = arg0.getKeyChar();
        if (!myDisable) {
            switch (key) {
                case 'a':
                    myBoard.moveLeft();
                    break;
                case 'd':
                    myBoard.moveRight();
                    break;
                case 'w':
                    myBoard.rotate();
                    break;
                case 's':
                    myBoard.moveDown();
                    break;
                case 'x':
                    myBoard.hardDrop();
                    break;
                default:
                    System.out.println("did you add an extra key?");
                    break;
            }
        }
        if (key == 'p') {
            Tick.startStop();
            toggleDisable();
        }   
    }
    /**
     * This toggles myDisable.
     */
    private void toggleDisable() {
        myDisable = !myDisable;
    }
           

}



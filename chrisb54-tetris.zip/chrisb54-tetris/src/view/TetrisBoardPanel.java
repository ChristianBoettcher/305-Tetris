package view;

import java.awt.Color; 
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;
import model.AbstractPiece;
import model.Block;
import model.Board;
/**
 * the graphic representation of a tetris board.
 * @author Christian
 * @version Dec. 11 2015
 */
class TetrisBoardPanel extends JPanel implements Observer {

    /**
     * the serial number for this class.
     */
    private static final long serialVersionUID = -5529099128337675583L;
    /**
     * Roman numeral 10.
     */
    private static final int X = 10;
    /**
     * Roman numeral 20.
     */
    private static final int XX = 20;
    /**
     * the state on whether to display a grid.
     */
    private static boolean myGrid;
    /** 
     * the Board object to made into a visible representation.
     */
    private final Board myBoard;
    /**
     * a list of Rectangles made from each current piece and used to draw them.
     */
    private List<Rectangle2D.Double> myDrawnBlocks;
    /**
     * a list of frozen blocks to draw (only draws the ones not empty).
     */
    private List<Block []> myFrozenBlocks;
    /**
     * the scale of which to draw the blocks and the board.
     */
    private int myScl;
    /**
     * the constructor.
     * @param theBoard = the Board object passed from TetrisGUI to be acted upon.
     */
    public TetrisBoardPanel(final Board theBoard) {
        super();
        myScl = TetrisGUI.getScale();
        this.setPreferredSize(new Dimension(myScl * X, myScl * XX - X));
        this.setBackground(Color.WHITE);
        myBoard =  theBoard;
        myDrawnBlocks = new ArrayList<Rectangle2D.Double>();
        myFrozenBlocks = myBoard.getFrozenBlocks();
        myGrid = false;
    }
    
    @Override
    public void paintComponent(final Graphics theGraphics) {
        super.paintComponent(theGraphics);
        final Graphics2D g2d = (Graphics2D) theGraphics; 
        int space = 0;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);
        if (myGrid) {
            for (int i = 0; i < myBoard.getWidth(); i++) {
                space = i * myScl;
                g2d.draw(new Line2D.Double(space, 0, space, 
                                           (myBoard.getHeight() + 1) * myScl));
            }
            for (int i = 0; i < myBoard.getHeight() + 2; i++) {
                space = i * myScl;
                g2d.draw(new Line2D.Double(0, space, this.getWidth(), space));
            }
        }
        for (Rectangle2D.Double s : myDrawnBlocks) {
            g2d.setPaint(Color.GRAY);
            g2d.fill(s);
            g2d.setPaint(Color.BLACK);
            g2d.draw(s);
        }
        for (int i = 0; i < myFrozenBlocks.size(); i++) {
            int anX = 0;
            int aY = 0;
            Rectangle2D.Double aSquare;
            for (int j = 0; j < myFrozenBlocks.get(i).length; j++) {
                if (myFrozenBlocks.get(i)[j] != Block.EMPTY) {
                    anX = j * myScl;
                    aY = ((myBoard.getHeight() - i) * myScl) - myScl;
                    aSquare = new Rectangle2D.Double(anX, aY, myScl, myScl);
                    g2d.setPaint(Color.GRAY);
                    g2d.fill(aSquare);
                    g2d.setPaint(Color.BLACK);
                    g2d.draw(aSquare);
                 
                }
            }   
        }
    }

    @Override
    public void update(final Observable arg0, final Object arg1) {
        final Board board = (Board) arg0;
        myDrawnBlocks.clear();
        final int[][] current = ((AbstractPiece)
                        (myBoard.getCurrentPiece())).getBoardCoordinates();
        for (int i = 0; i < current.length; i++) {
            System.out.print(current[i][0] + "," + current[i][1] + " ");
        }
        System.out.println();
        
        assemblePiece(current);

        repaint();
        
        System.out.println(board);
        
    }
    /**
     * this method draws squares from each coordinate of the currently active piece.
     * @param theCurrent = the coordinate array for each square of the current piece.
     */
    private void assemblePiece(final int[][] theCurrent) {
        for (int i = 0; i < theCurrent.length; i++) {
            int anX = 0;
            int aY = 0;
            Rectangle2D.Double aSquare;
           
            anX = theCurrent[i][0] * myScl;
            aY = ((myBoard.getHeight() - theCurrent[i][1]) * myScl) - myScl;
               
            aSquare = new Rectangle2D.Double(anX, aY, myScl, myScl);
            myDrawnBlocks.add(aSquare);
            
        }
        System.out.println();
    }
    /**
     * toggles the grid.
     * @param theIsSelected = the boolean variable passed from a JMenuCheckBox.
     */
    public static void setGrid(final boolean theIsSelected) {
        myGrid = theIsSelected;
    }
}

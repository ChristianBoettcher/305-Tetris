package view;

import java.awt.Color; 
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;

import model.AbstractPiece;
import model.Block;
import model.Board;
import model.Piece;

/**
 * the panel to display the next piece.
 * @author Christian Boettcher
 * @version Dec. 12 2015
 */
public class NextPiecePanel extends JPanel implements Observer {
    
    /**
     * the serial number for this object.
     */
    private static final long serialVersionUID = -1032980504571126197L;
    /**
     * Roman numeral 5.
     */
    private static final int V = 5;
    /**
     * Roman numeral 10.
     */
    private static final int X = 10;
    /**
     * Roman numeral 15.
     */
    private static final int XV = 15;
    /**
     * Roman numeral 20.
     */
    private static final int XX = 20;
    /**
     * Roman numeral 25.
     */
    private static final int XXV = 25;
    /**
     * Roman numeral 30.
     */
    private static final int XXX = 30;
    /**
     * Roman numeral 65.
     */
    private static final int LXV = 65;
    /**
     * the array of shape object that will be printed out.
     */
    private final Shape[] myShape;
    /**
     * the constructor which initializes the variables, sets up the myShape[] w/ 2 slots
     * and puts in dummy rectangles.
     * @param theDim = the Dimensions for this panel.
     */
    public NextPiecePanel(final Dimension theDim) {
        super();
        this.setSize(theDim);
        this.setBackground(Color.CYAN);
        myShape = new Shape[2];
        myShape[0] = new Rectangle2D.Double();
        myShape[1] = new Rectangle2D.Double();
    }
    
    @Override
    public void paintComponent(final Graphics theGraphics) {
        super.paintComponent(theGraphics);
        final Graphics2D g2d = (Graphics2D) theGraphics; 
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);
        for (Shape s : myShape) {
            g2d.setPaint(Color.GRAY);
            g2d.fill(s);
        }
        g2d.drawString("NEXT PIECE", V, LXV);
    }

    @Override
    public void update(final Observable arg0, final Object arg1) {
        final Piece aPiece = ((Board) arg0).getNextPiece();
        buildNextPiece(aPiece);
        repaint();

    }
    /**
     * this assembles the next piece, given the next Piece object from the board,
     * and creates a visual representation out of 2 Rectangle2D.Double's.
     * 
     * @param thePiece =  the next piece from the Board.
     */
    private void buildNextPiece(final Piece thePiece) {
        final Block aBlock = ((AbstractPiece) thePiece).getBlock();
        switch (aBlock) {
            case I:
                myShape[0] = new Rectangle2D.Double(V, XV, XX, X);
                myShape[1] = new Rectangle2D.Double(XXV, XV, XX, X);
                break;

            case J:
                myShape[0] = new Rectangle2D.Double(V, XV, X, XX);
                myShape[1] = new Rectangle2D.Double(XV, XXV, XX, X);
                break;

            case L:
                myShape[0] = new Rectangle2D.Double(V, XXV, XX, X);
                myShape[1] = new Rectangle2D.Double(XXV, XV, X, XX);
                break;

            case O:
                myShape[0] = new Rectangle2D.Double(V, XV, X, XX);
                myShape[1] = new Rectangle2D.Double(XV, XV, X, XX);
                break;

            case S:
                myShape[0] = new Rectangle2D.Double(XV, XV, XX, X);
                myShape[1] = new Rectangle2D.Double(V, XXV, XX, X);
                break;

            case T:
                myShape[0] = new Rectangle2D.Double(XV, XV, X, X);
                myShape[1] = new Rectangle2D.Double(V, XXV, XXX, X);
                break;

            case Z:
                myShape[0] = new Rectangle2D.Double(V, XV, XX, X);
                myShape[1] = new Rectangle2D.Double(XV, XXV, XX, X);
                break;

            default: 
                System.out.println("you added a new piece, didn't you");
                break;
        }
    }

}

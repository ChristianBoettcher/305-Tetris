package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.util.Observer;

import javax.swing.JPanel;
import javax.swing.JTextArea;

import model.Board;

/**
 * the stats viewing panel to display next piece, controls, and the level.
 * @author Christian
 * @version Dec. 11 2015
 */
public class StatsViewPanel extends JPanel {

    /**
     * the serial number for this class.
     */
    private static final long serialVersionUID = -4670610653870252155L;
    /**
     * Roman numeral 3.
     */
    private static final int III = 3;
    /**
     * the Board object to be acted upon.
     */
    private final Board myBoard;
    /**
     * the desired dimension for each panel.
     */
    private final Dimension myDim;
    /**
     * the constructor setting up a 3 x 1 grid panel to display the next piece, 
     * the controls, and the score.
     * @param theBoard =  the board object to be acted upon.
     */
    public StatsViewPanel(final Board theBoard) {
        super();
        setLayout(new GridLayout(III, 1));
        myBoard = theBoard;
        final int scl = TetrisGUI.getScale();
        myDim = new Dimension(scl * III, scl * III);
        setup();
    }
    /**
     * this method sets up the layout of the StatsViewPanel.
     */
    private void setup() {
        final NextPiecePanel aNextPiece = new NextPiecePanel(myDim);
        myBoard.addObserver((Observer) aNextPiece);
        final JTextArea aControls = controlsPanel(); 
        final ScorePanel aScore = new ScorePanel(myDim);
        myBoard.addObserver((Observer) aScore);
        
        add(aNextPiece); 
        add(aControls);
        add(aScore);
    }
    /**
     * this creates a panel to display the controls.
     * @return controls =  the JTextArea displaying the controls.
     */
    private JTextArea controlsPanel() {
        final JTextArea controls = new JTextArea();
        controls.setSize(myDim);
        controls.setBackground(Color.GRAY);
        final String ctrStr = "a: left \nd: right \ns: down \nw: rotate \n"
                        + "x: hard drop \np: pause";
        controls.setText(ctrStr);
        return controls;
    }
    @Override
    public void paintComponent(final Graphics theGraphics) {
        super.paintComponent(theGraphics);
        final Graphics2D g2d = (Graphics2D) theGraphics; 
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);
    }
}

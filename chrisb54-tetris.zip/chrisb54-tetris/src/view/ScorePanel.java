package view;

import java.awt.Color; 
import java.awt.Dimension;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JTextArea;

import model.Board;
/**
 * This class will make the Score panel for Tetris.
 * 
 * @author Christian
 * @version Dec. 11 2015
 */
public class ScorePanel extends JTextArea implements Observer {
    /**
     * the serial number for this class.
     */
    private static final long serialVersionUID = -6670061198742314026L;
    /**
     * the points earned per line cleared.
     */
    private static final int PTS = 15;
    /**
     * how many lines to clear to get to the next level.
     */
    private static final int LINES_TO_CLEAR = 3;
    /**
     * the level the player is currently on.
     */
    private static int myLevel;
    /**
     * the number of lines cleared.
     */
    private static int myLinesCleared;
    /**
     * the number of lines until next level.
     */
    private static int myTilNextLevel;
    /**
     * the size of the frozen blocks (used for scoring).
     */
    private static int myFrozenSize;
    /**
     * the string displaying the game status to the player.
     */
    private String myScStr;
   

    /**
     * the constructor method initializing variables.
     * @param theDim = the dimensions for this panel.
     */
    public ScorePanel(final Dimension theDim) {
        super();
        this.setSize(theDim);
        this.setText(myScStr);
        this.setBackground(Color.CYAN);
        myLinesCleared = 0;
        myLevel = 1;
        myTilNextLevel = 0;
    }

    @Override
    public void update(final Observable arg0, final Object arg1) {
        final Board board = (Board) arg0;
        myTilNextLevel = (LINES_TO_CLEAR * myLevel) - myLinesCleared; 
        if (board.getFrozenBlocks().size() < myFrozenSize) {  
            myLinesCleared++;
            myFrozenSize = board.getFrozenBlocks().size();    
        } else {
            myFrozenSize = board.getFrozenBlocks().size(); 
        }
        if (myTilNextLevel < 1) {
            myLevel++;
            
        }

        myScStr = "Level" + myLevel + "\n" + myLinesCleared + ": lines cleared \n" 
                        + (myLinesCleared * PTS) + ": points \n" + myTilNextLevel 
                        + ": lines til next\n   level"; 
        this.setText(myScStr);
    }
    /**
     * this returns current level (used for Tick Class to speed up the timer).
     * 
     * @return myLevel = the current level.
     */
    public static int getLevel() {
        return myLevel;
    }
    /**
     * resets the variables (used in a new game).
     */
    public static void resetScore() {
        myLevel = 1;
        myLinesCleared = 0;
        myTilNextLevel = 0;
        myFrozenSize = 0;
    }

}

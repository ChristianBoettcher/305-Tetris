package view;

import java.awt.BorderLayout;  
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.util.Observer;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import model.Block;
import model.Board;
/**
 * the GUI for Tetris.
 * @author Christian
 * @version Dec. 11 2015
 */
public class TetrisGUI extends JFrame {

    /**
     * 
     */
    private static final long serialVersionUID = 3565967896122405751L;
    /**
     * the scale of each block (pxl by pxl).
     */
    private static final int SCALE = 20;
    /**
     * the height of the tetris board.
     */
    private static final int HEIGHT = 20;
    /**
     * the width of the tetris board.
     */
    private static final int WIDTH = 10;
    /**
     * the Board object to be acted upon.
     */
    private final Board myBoard;
    /**
     * the Tick object which is responsible for handling the speed of the game.
     */
    private final Tick myTimer;
    /**
     * a key listener which coordinates key strokes to Board movement behavior.
     */
    private final MoveListener myMove;
    /**
     * the constructor for the GUI.
     */
    public TetrisGUI() {
        super("Tetris");
        myBoard = new Board(WIDTH, HEIGHT);
        myTimer = new Tick(myBoard);
        myMove = new MoveListener(myBoard);
        this.addKeyListener(myMove);
        this.setFocusable(true);
       
        setupAppearance();
        
        myTimer.start();
    }
    
    /**
     * the method called from TetrisMain that starts the game.
     */
    public static void start() {
        new TetrisGUI();
    }
    
    /**
     * this method sets up the general layout for the GUI.
     */
    public void setupAppearance() {
        final TetrisBoardPanel aTetrisBoardPanel = new TetrisBoardPanel(myBoard);
        myBoard.addObserver((Observer) aTetrisBoardPanel);
    
        setJMenuBar(createMenuBar(TetrisGUI.this, myBoard));
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(aTetrisBoardPanel, BorderLayout.WEST);
        add(new StatsViewPanel(myBoard), BorderLayout.CENTER);
        pack();
        this.setResizable(false);
        setVisible(true); 
    }
    
    /**
     * this method creates the JMenu for the GUI.
     * 
     * @param theFrame = the JFrame that contains the whole GUI.
     * @param theBoard = the Board object to be acted upon.
     * @return menuBar
     */
    private JMenuBar createMenuBar(final JFrame theFrame, final Board theBoard) {
        final JMenuBar menuBar = new JMenuBar();
        
        menuBar.add(buildFileMenu(theFrame, theBoard));
        menuBar.add(buildOptionMenu());
        menuBar.add(buildHelpMenu());
        
        return menuBar;
    }
    /**
     * this method builds the file menu for starting, ending and exiting the game.
     * 
     * @param theFrame = the whole GUI JFrame.
     * @param theBoard = the Board object to be acted upon.
     * @return fileMenu =  the file menu.
     */
    private JMenu buildFileMenu(final JFrame theFrame, final Board theBoard) {
        final JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        
        fileMenu.add(buildExitItem(theFrame));
        fileMenu.addSeparator();
        fileMenu.add(buildNewGameItem(theBoard));
        fileMenu.addSeparator();
        fileMenu.add(buildEndGameItem(theBoard));
        return fileMenu;
    }
    /**
     * this method makes the exit JmenuItem.
     * @param theFrame = the whole JFrame containing the GUI.
     * @return exitItem = the item that exits out of the game.
     */
    private JMenuItem buildExitItem(final JFrame theFrame) {    
        final JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.setMnemonic(KeyEvent.VK_X);
        exitItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_X, ActionEvent.META_MASK));
        exitItem.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                theFrame.dispatchEvent(new WindowEvent(theFrame, WindowEvent.WINDOW_CLOSING));
            }
        });
        return exitItem;
    }
    /**
     * this method provides a way for the user to start a new game.
     * @param theBoard = the board to be acted upon.
     * @return newGameItem = item to start a new game (only works if the game has ended). 
     */
    private JMenuItem buildNewGameItem(final Board theBoard) {    
        final JMenuItem newGameItem = new JMenuItem("New Game");
        newGameItem.setMnemonic(KeyEvent.VK_N);
        newGameItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_N, ActionEvent.META_MASK));
        newGameItem.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                if (theBoard.isGameOver()) {
                    theBoard.newGame(HEIGHT, WIDTH, null);
                    myTimer.start();
                    ScorePanel.resetScore();
                }
            }
        });
        return newGameItem;
    }
    /**
     * this method provides a way for the user to end a new game.
     * @param theBoard = the board to be acted upon.
     * @return endGameItem = an item to end a game.
     */
    private JMenuItem buildEndGameItem(final Board theBoard) {    
        final JMenuItem endGameItem = new JMenuItem("End Game");
        endGameItem.setMnemonic(KeyEvent.VK_E);
        endGameItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_E, ActionEvent.META_MASK));
        endGameItem.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                final Block e = Block.EMPTY;
                while (theBoard.getFrozenBlocks().size() <= theBoard.getHeight()) {
                    final Block[] row = new Block[theBoard.getWidth()];
                    for (int i = 0; i < row.length; i++) {
                            row[i] = e;
                    }
                    theBoard.getFrozenBlocks().add(row);
                }
                theBoard.hardDrop();
            }
        });
        return endGameItem;
    }
    /**
     * this method returns an option menu (only has a grid option).
     * @return optionMenu = the option menu.
     */
    private JMenu buildOptionMenu() {
        final JMenu optionMenu = new JMenu("Option");
        optionMenu.setMnemonic(KeyEvent.VK_O);
       
        optionMenu.add(buildGridItem());
        return optionMenu;
    }
    /**
     * creates a check box to turn on and of a grid.
     * @return gridItem =  a JMenuItem w/ a check box to toggle on and off a grid.
     */
    private JMenuItem buildGridItem() {
        final JMenuItem gridItem = new JMenuItem("Grid ");
        gridItem.setMnemonic(KeyEvent.VK_G);
        gridItem.setAccelerator(KeyStroke.getKeyStroke(
                                KeyEvent.VK_G, ActionEvent.META_MASK));
        final JCheckBox gridCheck = new JCheckBox("Grid");
        gridCheck.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                TetrisBoardPanel.setGrid(gridCheck.isSelected());
            }     
        });
        gridItem.add(gridCheck);
        return gridItem;
    }
    /**
     * creates a help item which will display a window giving general info.
     * @return helpMenu = the item which can display information.
     */
    private JMenu buildHelpMenu() {
        final JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        final JMenuItem aboutItem = new JMenuItem("About...");
        aboutItem.setMnemonic(KeyEvent.VK_A);
        aboutItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_A, ActionEvent.META_MASK));
        aboutItem.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                final JOptionPane about = new JOptionPane("About");
                final String dialog = "TCSS 305 Tetris - Autumn quarter\n" 
                    + "By Christian Boettcher\n\nThe player earns 15 pts. per line cleared.\n"
                    + "Each level will increase after 3 lines cleared.";
                JOptionPane.showMessageDialog(about, dialog);
                about.setVisible(true);
            }
        });    
        helpMenu.add(aboutItem);
        return helpMenu;
    }
    /**
     * A getter method for other classes to get the scale of the board
     * (which I now understand is bad object oriented programming, 
     *  but for now I'm keeping it).
     * @return SCALE = the scale of each block 
     * (please refer to the final static variables at the top).
     */
    public static int getScale() {
        return SCALE;
    }
    
}
